dir='~/Pictures/walls/image.jpg'
value=$(python ~/Desktop/python.py $dir)
echo $value