#. ~/Desktop/get_current_wallpaper_directory.sh
. ~/Documents/scripts/wallpaper_changer/sh/get_current_wallpaper_directory.sh
#wall_dir=$([ "$1" == "" ] && echo $walls_dir || echo $1)

#echo $wall_dir

# if [ $2 ]; then
# 				dir=$wall_dir
# 			else
# 				dir='~/Pictures/walls'
# 			fi

dir=$wall_dir
change='random'

function determine_input {
	case $1 in
		'default') dir='~/Pictures/walls';;
		'next') change='next';;
		'previous') change='previous';;
		*) ;;
	esac
}

determine_input $1
determine_input $2

python ~/Desktop/read_env.py $dir $change