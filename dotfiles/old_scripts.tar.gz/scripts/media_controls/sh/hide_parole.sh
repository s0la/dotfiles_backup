/home/sola/Documents/scripts/hide.sh 12
xfconf-query -c xfce4-panel -p /panels/panel-12/position -s 'p=0;x=1700;y=950'