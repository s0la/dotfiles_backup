#!/bin/bash

xdotool keydown alt key Insert
xdotool keyup alt