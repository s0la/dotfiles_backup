#!/bin/bash

xdotool keydown alt key Delete
xdotool keyup alt