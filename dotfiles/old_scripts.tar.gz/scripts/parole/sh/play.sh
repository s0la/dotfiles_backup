Documents/scripts/general/sh/shift.sh 3 1
parole -p