#!/bin/bash

Documents/scripts/general/sh/shift.sh 6 1
xfce4-terminal --drop-down