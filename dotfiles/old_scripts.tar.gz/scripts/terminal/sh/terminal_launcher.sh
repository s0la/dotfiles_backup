#!/bin/bash

Documents/scripts/general/sh/shift.sh 6 1
Documents/scripts/terminal/sh/terminal.sh