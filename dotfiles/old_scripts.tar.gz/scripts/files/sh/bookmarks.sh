#!/bin/bash

Documents/scripts/general/sh/shift.sh 7 1
xdotool keydown ctrl key b
xdotool keyup ctrl