Documents/scripts/general/shift.sh 4 2
transset -i $(printf 0x%x $(xdotool getactivewindow)) .9