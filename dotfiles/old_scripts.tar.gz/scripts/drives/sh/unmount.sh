#!/bin/bash

pkill rofi
gksudo umount $(df -h | awk '/'$1'/ {print $NF}')
