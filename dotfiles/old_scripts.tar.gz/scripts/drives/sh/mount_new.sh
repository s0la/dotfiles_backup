#!/bin/bash

drive=$1

if [ -z $(mount | grep $drive) ]; then
	case $drive in
		9*) dev=sda6;;
		6*) dev=sda5;;
	esac

	pkill rofi
	gksudo mount /dev/$dev /media/sola/$drive
fi

if ! wmctrl -a $drive; then
	thunar /media/sola/$drive
fi
