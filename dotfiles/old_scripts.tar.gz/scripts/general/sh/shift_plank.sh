pkill plank
plank -n $1