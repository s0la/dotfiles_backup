from pykeyboard import PyKeyboard
from pykeyboard import PyKeyboardEvent
from pymouse import PyMouseEvent
import os

keyboard = PyKeyboard()
keyboard.press_key(keyboard.alt_key)
keyboard.tap_key(keyboard.tab_key)

class Click(PyMouseEvent):

	def __init__(self):
		PyMouseEvent.__init__(self)

	def click(self, x, y, button, press):
		os.system('notify-send "x coordiante is %s"' % x)
		if button == 1:
			keyboard.release_key(keyboard.alt_key)
			self.stop()

class Press(PyKeyboardEvent):

	def __init__(self):
		PyKeyboardEvent.__init__(self)

	def key_press(self, keycode):

		os.system('notify-send "hello :)"')

		if keycode == self.lookup_character_value('Return'):
			os.system('notify-send "hello :)"')
			keyboard.release_key(keyboard.alt_key)
			self.stop()

Click().run()
