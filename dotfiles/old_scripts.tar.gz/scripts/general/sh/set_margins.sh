#!/bin/bash

xfconf-query -c xfwm4 -p /general/margin_bottom -s 200
xfconf-query -c xfwm4 -p /general/margin_top -s 100
xfconf-query -c xfwm4 -p /general/margin_left -s 100
xfconf-query -c xfwm4 -p /general/margin_right -s 100