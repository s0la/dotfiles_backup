thunar &
sleep 0.1
transset -i $(printf 0x%x $(xdotool getactivewindow)) 0.88