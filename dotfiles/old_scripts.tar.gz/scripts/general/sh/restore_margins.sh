#!/bin/bash

xfconf-query -c xfwm4 -p /general/margin_bottom -s 50
xfconf-query -c xfwm4 -p /general/margin_top -s 0
xfconf-query -c xfwm4 -p /general/margin_left -s 0
xfconf-query -c xfwm4 -p /general/margin_right -s 0