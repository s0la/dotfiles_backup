#!/bin/bash

Documents/scripts/general/sh/shift.sh 4 1
gmusicbrowser -cmd PlayPause