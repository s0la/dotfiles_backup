#!/bin/bash

Documents/scripts/general/sh/shift.sh 4 1
gmusicbrowser -cmd OpenQueue
#Documents/scripts/general/sh/make_transparent.sh