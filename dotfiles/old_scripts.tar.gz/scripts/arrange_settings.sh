mkdir Documents/backup-desktop
sudo mv /usr/share/applications/mugshot.desktop Documents/backup-desktop/
sudo mv /usr/share/applications/menulibre.desktop Documents/backup-desktop/
sudo mv /usr/share/applications/language-selector.desktop Documents/backup-desktop/
sudo mv /usr/share/applications/gtk-theme-config.desktop Documents/backup-desktop/
sudo mv /usr/share/applications/blueman-manager.desktop Documents/backup-desktop/
sudo mv /usr/share/applications/xfce4-accessibility-settings.desktop Documents/backup-desktop/
sudo mv /usr/share/applications/ubiquity.desktop Documents/backup-desktop/
sudo mv /usr/share/applications/users.desktop Documents/backup-desktop/
sudo mv /usr/share/applications/blueman-adapters.desktop Documents/backup-desktop/
sudo mv /usr/share/applications/xfce4-notifyd-config.desktop Documents/backup-desktop/
sudo mv /usr/share/applications/xfpanel-switch.desktop Documents/backup-desktop/
sudo mv /usr/share/applications/xfce4-mime-settings.desktop Documents/backup-desktop/
sudo mv /usr/share/applications/exo-preferred-applications.desktop Documents/backup-desktop/
sudo mv /usr/share/applications/xfce-workspaces-settings.desktop Documents/backup-desktop/
sudo mv /usr/share/applications/xfce-wmtweaks-settings.desktop Documents/backup-desktop/
sudo mv /usr/share/applications/software-properties-gtk.desktop Documents/backup-desktop/